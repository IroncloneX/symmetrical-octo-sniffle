/*CMD
  command: Helpp
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Post

  <<ANSWER
*Question *
How do I setup my group or channel?
*Answer*
1. type command `/setupcha`
2. Choose your channel option
3. Write your channel username
4. Post a message to your channel
5. Check your channel.
  ANSWER
  keyboard: 
  aliases: 
CMD*/

