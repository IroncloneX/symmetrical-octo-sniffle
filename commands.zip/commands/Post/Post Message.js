/*CMD
  command: Post Message
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Post
  answer: Welcome to post message mode. Your can post messages using this bot.
  keyboard: Create Post, Helpp, \nSetup, MAIN Menu
  aliases: 
CMD*/

