/*CMD
  command: /delcha3
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Post
  answer: 
  keyboard: 
  aliases: 
CMD*/

User.setProperty("post3")
Bot.runCommand("/cha33")
