/*CMD
  command: /delcha1
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Post
  answer: 
  keyboard: 
  aliases: 
CMD*/

User.setProperty("post1")
Bot.runCommand("/cha1")
